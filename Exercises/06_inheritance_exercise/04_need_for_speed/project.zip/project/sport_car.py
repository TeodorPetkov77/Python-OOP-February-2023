from project.car import Car
from project.family_car import FamilyCar
from project.vehicle import Vehicle


class SportCar(Car):
    DEFAULT_FUEL_CONSUMPTION = 10
    pass


