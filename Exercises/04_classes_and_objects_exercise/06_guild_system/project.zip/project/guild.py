from project.player import Player


class Guild:
    def __init__(self, name):
        self.name = name
        self.players = []

    def assign_player(self, player):
        if player not in self.players:
            if player.guild == "Unaffiliated":
                self.players.append(player)
                player.guild = self.name
                return f"Welcome player {player.name} to the guild {self.name}"
            else:
                return f"Player {player.name} is in another guild."
        else:
            return f"Player {player.name} is already in the guild."

    def kick_player(self, player_name: str):
        for name in self.players:
            if name.name == player_name:
                self.players.remove(name)
                name.guild = "Unaffiliated"
                return f"Player {player_name} has been removed from the guild."
        else:
            return f"Player {player_name} is not in the guild."

    def guild_info(self):
        return f"Guild: {self.name}\n" + "\n".join([info.player_info() for info in self.players])


player = Player("George", 50, 100)
print(player.add_skill("Shield Break", 20))
print(player.player_info())
guild = Guild("UGT")
print(guild.assign_player(player))
print(guild.guild_info())
teo = Player("Teo", 75, 200)
sasho = Player("Sasho", 80, 180)
print(teo.add_skill("Fireball", 20))
print(teo.add_skill("Iceblock", 20))
print(sasho.add_skill("Ambush", 60))
print(sasho.add_skill("Backstab", 40))
print(guild.assign_player(teo))
print(guild.assign_player(teo))
print(guild.assign_player(sasho))
print(guild.kick_player("Teo"))
print(guild.kick_player("Sasho"))
print(guild.guild_info())